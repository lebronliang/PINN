# Validation of the Excel example workflow

The included example was run through `run_excel_pipeline.py --solver numerical`.
The included example results were obtained using the BDF solver.

- The original seven-column layout and event-label merges were retained. Only example failure counts were replaced.
- Input coverage: 21 event categories, six annual indices, 47,836 station operating hours.
- Both numerical models loaded the exact JSON parameters produced by the Excel estimator.
- Numerical settings: BDF, analytic Jacobian, relative tolerance 1e-9, absolute tolerance 1e-11, 3,001 output times over 0–150,000 h.
- Tightening tolerances to 1e-11 and 1e-13 changed state probabilities by at most 1.387e-9 and the restricted mean first-passage time by approximately 3.026e-7 h.
- Unit/integration checks: 26 tests, 25 passed; the TensorFlow training test was skipped because TensorFlow was not installed in the local test environment.
- Numerical tests include a known two-state repair solution, a time-varying first-passage solution, and a zero-departure case.
- Excel checks include merged labels, missing and fractional counts, duplicate event-years, inconsistent hours, stale midpoints, input changes reaching fitted parameters, and output overwrite protection.

Results and diagnostic details are under `example_results/`. A short test run or numerical solution of this example does not assess the accuracy of a trained PINN.
