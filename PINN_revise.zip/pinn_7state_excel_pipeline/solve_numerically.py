"""BDF solution of the fitted seven-state Markov model; no TensorFlow required."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.integrate import solve_ivp

from model_parameters import load_parameters


def generator_transpose(t, parameters, absorbing=False):
    rates = parameters.intercepts + parameters.slopes * t
    recovery = parameters.recovery_rates.copy()
    if absorbing:
        recovery[3:] = 0
    matrix = np.zeros((7, 7))
    matrix[0, 0] = -rates.sum()
    matrix[0, 1:] = recovery
    matrix[1:, 0] = rates
    matrix[np.arange(1, 7), np.arange(1, 7)] = -recovery
    return matrix


def solve(parameters, points=3001, rtol=1e-9, atol=1e-11):
    parameters.validate()
    if points < 2 or not np.isfinite(rtol) or not np.isfinite(atol) or min(rtol, atol) <= 0:
        raise ValueError('Use >=2 evaluation points and finite positive tolerances.')
    times = np.linspace(0, parameters.assessment_horizon_h, points)
    def augmented_matrix(t, absorbing):
        # Extra variables integrate indicators; the physical model has seven states.
        dimension = 8 if absorbing else 9
        matrix = np.zeros((dimension, dimension))
        matrix[:7, :7] = generator_transpose(t, parameters, absorbing)
        if absorbing:
            matrix[7, :4] = 1
        else:
            matrix[7, 0] = 1
            matrix[8, :4] = 1
        return matrix
    solutions, elapsed = [], []
    for absorbing in (False, True):
        initial = np.zeros(8 if absorbing else 9)
        initial[0] = 1
        start = perf_counter()
        result = solve_ivp(lambda t, y: augmented_matrix(t, absorbing) @ y,
                           (0, times[-1]), initial, t_eval=times, method='BDF',
                           jac=lambda t, y: augmented_matrix(t, absorbing), rtol=rtol, atol=atol)
        elapsed.append(perf_counter() - start)
        if not result.success:
            raise ValueError(f'BDF failed: {result.message}')
        solutions.append(result)
    main, aux = solutions
    probabilities, first_passage = main.y[:7].T, aux.y[:7].T
    checks = {}
    for label, values in [('main', probabilities), ('first_passage', first_passage)]:
        checks[label] = dict(min_probability=float(values.min()), max_probability=float(values.max()),
                             max_normalization_error=float(np.max(np.abs(values.sum(axis=1) - 1))),
                             initial_condition_error=float(np.max(np.abs(values[0] - np.eye(7)[0]))))
        if values.min() < -1e-7 or values.max() > 1 + 1e-7 or checks[label]['max_normalization_error'] > 1e-7:
            raise ValueError(f'{label}: numerical probability checks failed.')
    resistance = probabilities[:, 0]
    absorption = probabilities[:, :4].sum(axis=1)
    hazard = parameters.intercepts.sum() * times + .5 * parameters.slopes.sum() * times**2
    survival_no_departure = np.exp(-hazard)
    departed = -np.expm1(-hazard)
    recovery = np.divide(resistance - survival_no_departure, departed,
                          out=np.zeros_like(times), where=departed > 1e-12)
    recovery = np.clip(recovery, 0, 1)
    robustness = np.clip(first_passage[:, :4].sum(axis=1), 0, 1)
    indices = np.column_stack([times, resistance, absorption, recovery, robustness, aux.y[7],
                               probabilities[:, 4:].sum(axis=1)])
    peak = int(np.argmax(recovery))
    summary = [
        ('Final resistance', resistance[-1], 'probability'),
        ('Time-averaged resistance', main.y[7, -1] / times[-1], 'probability'),
        ('Final absorption', absorption[-1], 'probability'),
        ('Time-averaged absorption', main.y[8, -1] / times[-1], 'probability'),
        ('Final recovery', recovery[-1], 'conditional probability'),
        ('Peak recovery on evaluation grid', recovery[peak], 'conditional probability'),
        ('Peak recovery time on evaluation grid', times[peak], 'h'),
        ('Final robustness survival probability', robustness[-1], 'probability'),
        ('Restricted mean first-passage time', aux.y[7, -1], 'h'),
        ('Final failure-state probability', probabilities[-1, 4:].sum(), 'probability'),
    ]
    report = dict(method='SciPy solve_ivp / BDF with analytic Jacobian', rtol=rtol, atol=atol,
                  evaluation_points=points, assessment_horizon_h=float(times[-1]),
                  main_solver_seconds=elapsed[0], first_passage_solver_seconds=elapsed[1],
                  main_nfev=main.nfev, first_passage_nfev=aux.nfev, probability_checks=checks,
                  integration_note='Indicator integrals are additional quadrature variables in BDF, not trapezoidal approximations on the output grid.',
                  input_mode=parameters.provenance.get('mode'),
                  recovery_at_zero='Defined as zero for plotting; no departure has occurred at t=0.')
    return times, probabilities, first_passage, indices, summary, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parameters', required=True)
    parser.add_argument('--output', type=Path, default=Path('results_numerical'))
    parser.add_argument('--points', type=int, default=3001)
    parser.add_argument('--rtol', type=float, default=1e-9)
    parser.add_argument('--atol', type=float, default=1e-11)
    args = parser.parse_args()
    try:
        if args.output.exists():
            raise ValueError('Output already exists; choose a new directory.')
        parameters = load_parameters(args.parameters)
        times, p, first, indices, summary, report = solve(parameters, args.points, args.rtol, args.atol)
        args.output.mkdir(parents=True)
        tables = {
            'state_probabilities.csv': (['time_h'] + [f'probability_S{k}' for k in range(7)], np.column_stack([times, p])),
            'first_passage_probabilities.csv': (['time_h'] + [f'probability_S{k}' for k in range(7)], np.column_stack([times, first])),
            'resilience_indices.csv': (['time_h', 'resistance', 'absorption', 'recovery', 'robustness_survival',
                                        'robustness_time_margin_h', 'failure_probability'], indices),
            'resilience_summary.csv': (['indicator', 'value', 'unit'], summary),
        }
        for name, (header, rows) in tables.items():
            with (args.output / name).open('w', encoding='utf-8', newline='') as stream:
                writer = csv.writer(stream); writer.writerow(header); writer.writerows(rows)
        for name, content in [('parameters_used.json', parameters.to_dict()), ('solver_report.json', report)]:
            (args.output / name).write_text(json.dumps(content, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')
        for label, value, unit in summary:
            print(f'{label}: {value:.10g} {unit}')
        print(f'Numerical results: {args.output.resolve()}')
    except (ValueError, OSError, KeyError) as error:
        parser.exit(2, f'Numerical solution error: {error}\n')


if __name__ == '__main__':
    main()
