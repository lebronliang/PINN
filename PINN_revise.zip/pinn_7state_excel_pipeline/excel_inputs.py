"""Read the supplied seven-column, single-station Excel statistics template."""
from __future__ import annotations

import csv
import hashlib
from pathlib import Path
import re

import numpy as np
from openpyxl import load_workbook

from estimate_parameters import integer, number
from model_parameters import STATES


def normalize(value):
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


HEADERS = [
    {"event id", "basic_event_id"},
    {"station state", "state"},
    {"failure or event type", "failure category"},
    {"year", "year index"},
    {"station operating time (h)", "annual station operating time (h)"},
    {"number of failures, n", "failure_count"},
    {"midpoint for fitting, t (h)", "midpoint for fitting (h)"},
]


def read_excel_statistics(path, sheet=None):
    """Validate all inputs before writing anything. No missing count becomes zero.

    A-C may be vertically merged. Only actual merged
    cells inherit their anchor value; ordinary empty cells are rejected.
    Model time is cumulative station operating hours from the first period start.
    """
    path = Path(path)
    book = load_workbook(path, data_only=False, read_only=False)
    try:
        if sheet:
            if sheet not in book.sheetnames:
                raise ValueError(f"Worksheet not found: {sheet}")
            ws = book[sheet]
        else:
            matches = [s for s in book if all(normalize(s.cell(1, j + 1).value) in aliases
                                             for j, aliases in enumerate(HEADERS))]
            if len(matches) != 1:
                raise ValueError("Expected exactly one worksheet with the seven template headers; use --sheet to select it.")
            ws = matches[0]
        for j, aliases in enumerate(HEADERS, 1):
            if normalize(ws.cell(1, j).value) not in aliases:
                raise ValueError(f"{ws.title}: unexpected header in column {j}: {ws.cell(1, j).value!r}")
        inherited = {}
        for merged in ws.merged_cells.ranges:
            if merged.min_col <= 7 and merged.max_row >= 2:
                if merged.min_col != merged.max_col or merged.min_col > 3 or merged.min_row < 2:
                    raise ValueError("Only vertical merges in data columns A-C are supported.")
                value = ws.cell(merged.min_row, merged.min_col).value
                for row in range(merged.min_row, merged.max_row + 1):
                    inherited[(row, merged.min_col)] = value
        mapping, rows, keys, years_by_event = {}, [], set(), {}
        schedule = {}
        for row in range(2, ws.max_row + 1):
            cells = [ws.cell(row, col) for col in range(1, 8)]
            # Ignore wholly empty unmerged trailing rows, never a blank year inside a block.
            if all(c.value is None for c in cells) and not any((row, col) in inherited for col in range(1, 4)):
                continue
            values = [inherited.get((row, col), cells[col - 1].value) for col in range(1, 8)]
            if any(c.data_type == "f" for c in cells[:6]):
                raise ValueError(f"Row {row}: A-F must contain input values, not formulas.")
            if any(v is None or str(v).strip() == "" for v in values[:6]):
                raise ValueError(f"Row {row}: missing input in A-F; enter 0 explicitly for a zero-failure period.")
            event, state, description = [str(v).strip() for v in values[:3]]
            if state not in STATES:
                raise ValueError(f"Row {row}: state must be S1-S6.")
            if event in mapping and mapping[event] != (state, description):
                raise ValueError(f"Row {row}: inconsistent state or description for {event}.")
            mapping[event] = state, description
            year = integer(values[3], f"row {row} year", 1)
            hours = number(values[4], f"row {row} operating hours")
            count = integer(values[5], f"row {row} failure count")
            if hours <= 0 or hours > 8784:
                raise ValueError(f"Row {row}: single-station annual operating hours must be >0 and <=8784; use the CSV interface for other exposure definitions.")
            key = event, year
            if key in keys:
                raise ValueError(f"Row {row}: duplicate event-year {key}.")
            keys.add(key)
            years_by_event.setdefault(event, set()).add(year)
            if year in schedule and not np.isclose(hours, schedule[year], rtol=0, atol=1e-6):
                raise ValueError(f"Row {row}: all event types must use the same station hours for year {year}.")
            schedule[year] = hours
            midpoint = None if cells[6].data_type == "f" or values[6] in (None, "") else number(values[6], f"row {row} midpoint")
            rows.append(dict(basic_event_id=event, state=state, year=year, exposure_h=hours,
                             failure_count=count, supplied_midpoint=midpoint, excel_row=row))
        if not rows or set(s for s, _ in mapping.values()) != set(STATES):
            raise ValueError("The Excel data must cover S1-S6.")
        years = sorted(schedule)
        if len(years) < 2:
            raise ValueError("At least two annual observations are required.")
        if any(b != a + 1 for a, b in zip(years, years[1:])):
            raise ValueError("Year labels must be consecutive; missing observation years must not silently become zero.")
        if any(value != set(years) for value in years_by_event.values()):
            raise ValueError("Every event category must cover the same station years; missing rows are not zero counts.")
        intervals, start = {}, 0.0
        for year in years:
            end = start + schedule[year]
            intervals[year] = start, end
            start = end
        for row in rows:
            begin, end = intervals[row['year']]
            midpoint = (begin + end) / 2
            supplied = row.pop('supplied_midpoint')
            if supplied is not None and not np.isclose(supplied, midpoint, rtol=0, atol=.001):
                raise ValueError(f"Row {row['excel_row']}: midpoint {supplied} is inconsistent with station hours (expected {midpoint}). Update G or leave it blank for automatic calculation.")
            row.update(time_start_h=begin, time_end_h=end, time_h=midpoint)
        summary = dict(filename=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                       worksheet=ws.title, year_labels=years, number_of_periods=len(years),
                       number_of_event_categories=len(mapping), total_station_operating_hours=start,
                       sum_of_category_failure_counts=sum(r['failure_count'] for r in rows),
                       count_note="Sum of category counts, not a deduplicated incident count unless categories are mutually exclusive.",
                       time_origin="t=0 is the start of cumulative station operating time in the first supplied period.")
        return mapping, sorted(rows, key=lambda r: (r['basic_event_id'], r['year'])), summary
    finally:
        book.close()


def write_csv_inputs(directory, mapping, observations):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    tables = {
        'basic_events.csv': (["basic_event_id", "state"],
                             [dict(basic_event_id=k, state=v[0]) for k, v in sorted(mapping.items())]),
        'annual_counts.csv': (["basic_event_id", "year", "failure_count"], observations),
        'annual_exposure.csv': (["basic_event_id", "year", "exposure_h", "time_start_h", "time_end_h"], observations),
    }
    for name, (fields, rows) in tables.items():
        with (directory / name).open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(rows)
