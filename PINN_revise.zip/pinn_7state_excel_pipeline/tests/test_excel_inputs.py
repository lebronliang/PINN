"""Regression checks for the public example and Excel-to-PINN interface."""
import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
from zipfile import ZipFile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from excel_inputs import read_excel_statistics
from model_parameters import load_parameters, baseline_parameters


def fixture_with_cells(destination, updates):
    """Alter test fixtures directly; never modify the delivered example."""
    ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with ZipFile(ROOT / 'data.xlsx') as src, ZipFile(destination, 'w') as out:
        for item in src.infolist():
            content = src.read(item.filename)
            if item.filename == 'xl/worksheets/sheet1.xml':
                tree = ET.fromstring(content)
                for address, value in updates.items():
                    cell = tree.find(f'.//m:c[@r="{address}"]', ns)
                    if cell is None:
                        raise AssertionError(f'Test fixture cell not found: {address}')
                    for child in list(cell):
                        cell.remove(child)
                    cell.attrib.pop('t', None)
                    if value is not None:
                        ET.SubElement(cell, '{'+ns['m']+'}v').text = str(value)
                content = ET.tostring(tree)
            out.writestr(item, content)


class ExcelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)

    def test_template_merges_station_schedule_and_midpoints(self):
        mapping, rows, source = read_excel_statistics(ROOT / 'data.xlsx')
        self.assertEqual(len(mapping), 21)
        self.assertEqual(len(rows), 126)
        self.assertEqual(source['year_labels'], list(range(1, 7)))
        self.assertEqual(source['total_station_operating_hours'], 47836)
        self.assertEqual(rows[0]['time_h'], 3981)
        self.assertEqual(rows[-1]['time_h'], 43843.5)
        self.assertTrue(all(r['failure_count'] >= 0 for r in rows))

    def test_missing_and_fractional_counts_rejected(self):
        for value in [None, -1, .5]:
            path = self.base / f'bad_{value}.xlsx'
            fixture_with_cells(path, {'F2': value})
            with self.assertRaises(ValueError):
                read_excel_statistics(path)

    def test_wrong_midpoint_and_shared_hours_rejected(self):
        for updates in [{'G2': 4000}, {'E8': 7000}, {'D3': 1}]:
            path = self.base / 'bad.xlsx'
            fixture_with_cells(path, updates)
            with self.assertRaises(ValueError):
                read_excel_statistics(path)

    def test_blank_midpoint_is_computed(self):
        path = self.base / 'blank_midpoint.xlsx'
        fixture_with_cells(path, {'G2': None})
        _, rows, _ = read_excel_statistics(path)
        self.assertEqual(rows[0]['time_h'], 3981)

    def run_fit(self, book, output):
        result = subprocess.run([sys.executable, str(ROOT / 'run_excel_pipeline.py'), '--excel', str(book),
                                 '--fit-only', '--output', str(output)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        return load_parameters(output / 'parameters/model_parameters.json')

    def test_excel_changes_reach_parameters_and_provenance(self):
        first = self.run_fit(ROOT / 'data.xlsx', self.base / 'a')
        self.assertEqual(first.provenance['mode'], 'estimated_from_example_statistics')
        self.assertEqual(first.provenance['input_metadata']['excel_source']['number_of_periods'], 6)
        self.assertFalse(np.allclose(first.intercepts, baseline_parameters().intercepts, rtol=1e-6, atol=0))
        path = self.base / 'changed.xlsx'
        fixture_with_cells(path, {'F2': 12})
        second = self.run_fit(path, self.base / 'b')
        self.assertNotEqual(first.intercepts[0], second.intercepts[0])
        np.testing.assert_allclose(first.intercepts[1:], second.intercepts[1:])
        result = subprocess.run([sys.executable, str(ROOT / 'run_excel_pipeline.py'), '--fit-only',
                                 '--output', str(self.base / 'a')], capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('already exists', result.stderr)


if __name__ == '__main__':
    unittest.main()
