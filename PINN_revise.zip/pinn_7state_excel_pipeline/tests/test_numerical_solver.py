"""Independent analytic checks of the numerical branch."""
import importlib.util
from pathlib import Path
import sys
import unittest
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from model_parameters import ModelParameters


@unittest.skipUnless(importlib.util.find_spec('scipy'), 'Install requirements-numerical.txt for BDF tests')
class NumericalTests(unittest.TestCase):
    def test_two_state_repair_solution(self):
        from solve_numerically import solve
        parameters = ModelParameters(np.array([.2, 0, 0, 0, 0, 0]), np.zeros(6),
                                     np.array([.3, 0, 0, 0, 0, 0]), 20, {})
        t, p, _, indices, _, _ = solve(parameters, 101)
        exact = .6 + .4 * np.exp(-.5 * t)
        np.testing.assert_allclose(p[:, 0], exact, atol=2e-9, rtol=1e-8)
        np.testing.assert_allclose(indices[:, 4], 1, atol=1e-10)
        self.assertAlmostEqual(indices[-1, 5], 20, places=7)

    def test_time_varying_first_passage_solution(self):
        from solve_numerically import solve
        parameters = ModelParameters(np.array([0, 0, 0, .1, 0, 0]),
                                     np.array([0, 0, 0, .02, 0, 0]), np.zeros(6), 10, {})
        t, p, _, indices, _, _ = solve(parameters, 101)
        exact = np.exp(-.1 * t - .01 * t*t)
        np.testing.assert_allclose(p[:, 0], exact, atol=3e-9, rtol=1e-8)
        np.testing.assert_allclose(indices[:, 4], exact, atol=3e-9, rtol=1e-8)
        np.testing.assert_allclose(indices[:, 3], 0, atol=2e-7)

    def test_no_departures(self):
        from solve_numerically import solve
        parameters = ModelParameters(np.zeros(6), np.zeros(6), np.zeros(6), 100, {})
        _, p, _, indices, _, _ = solve(parameters, 11)
        np.testing.assert_allclose(p[:, 0], 1)
        np.testing.assert_allclose(indices[:, 3], 0)
        self.assertAlmostEqual(indices[-1, 5], 100, places=7)


if __name__ == '__main__':
    unittest.main()
