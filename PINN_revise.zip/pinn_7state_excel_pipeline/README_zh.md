# Excel统计数据、参数拟合与PINN计算

## 数据说明

由于原始数据涉及企业位置、单位等敏感信息，无法公开。本包中的 `data.xlsx`
为示例数据，不能用于复现本文结果。本文结果复现详见
[pinn_7state_resilience.py](https://github.com/lebronliang/PINN/blob/main/pinn_7state_resilience.py)。

## 直接使用Excel

`data.xlsx` 沿用七列表格和合并单元格，包含21类底事件、6个年度区间。
年度编号1—6用于示例，不代表具体公历年份。各类事件共用单站运行时间，
累计47,836小时；故障次数为示例整数。程序会根据所填数据重新计算参数并传入PINN。

安装拟合依赖后，可先只计算参数：

```bash
python -m pip install -r requirements-estimation.txt
python run_excel_pipeline.py --excel data.xlsx --fit-only --output results_fit
```

安装训练依赖后，先做短训练试跑，再按需完整训练：

```bash
python -m pip install -r requirements.txt
python run_excel_pipeline.py --excel data.xlsx --smoke-test --output results_smoke
python run_excel_pipeline.py --excel data.xlsx --output results_full
```

`--smoke-test` 为两个PINN各训练5次，使用60个名义残差点和41个输出点，
仅检查流程是否能够运行，不能用其输出判断求解精度。完整训练默认两个PINN各80,000次。
可用 `--epochs 10000 --robustness-epochs 10000` 自行指定训练次数。
每次使用不同的输出目录；程序不会覆盖已有结果。

### 不训练PINN，直接查看数值结果

```bash
python -m pip install -r requirements-numerical.txt
python run_excel_pipeline.py --excel data.xlsx --solver numerical --output results_numerical
```

此命令拟合Excel参数后，使用SciPy BDF求解同一组状态方程及首次到达辅助方程，
不导入TensorFlow、不训练PINN。默认评估0—150,000 h，共3,001个输出点。
`--horizon-h` 可调整评估终点，`--evaluation-points` 可调整输出点数。
指标积分作为附加积分变量一同求解，避免结果依赖输出网格的梯形积分精度。
`numerical/` 中包含状态概率、首次到达概率、四个指标、汇总表和求解器检查。
包内 `example_results/` 是随附示例的实际数值计算输出；并未运行PINN训练。

### 换成自己的统计数据

保留第一行七个表头，替换数据行；A—C允许沿用纵向合并单元格。

| 列 | 内容与要求 |
|---|---|
| A | 底事件编号，同一事件每个年度一行 |
| B | 对应状态S1—S6，同一事件保持一致 |
| C | 事件类别说明 |
| D | 连续年度编号或公历年份；不是拟合使用的小时数 |
| E | 当年单站运行小时数；同一年各事件须使用相同数值 |
| F | 当年实际故障次数，填写非负整数；无故障填0，未知不能留空冒充0 |
| G | 累计运行时间的区间中点，可留空由程序计算 |

修改运行小时数后，应同步更新G列，或将G列数据留空。程序会核对已填中点，
防止沿用旧时间节点。G列若为Excel公式，程序会根据E列重新计算，不依赖公式缓存。
各事件须覆盖相同年度，至少两个年度；如不是单站累计运行时间口径，使用下方CSV接口。
使用自己的数据时，命令增加 `--data-kind user_statistics`；该选项只记录来源类别。

```text
本期失效率 = 本期故障次数 / 本期运行小时数
中点时间 = 前期累计运行小时数 + 本期运行小时数 / 2
失效率(t) = lambda_0 + alpha * t
```

`lambda_0` 是拟合截距，`alpha` 是拟合斜率，不是将全期平均失效率直接当作初始率。
默认采用非负约束最小二乘，并保留未约束拟合系数供检查。按示例映射进行独立OR门率加和后，
S1—S6参数传入主PINN、首次到达辅助PINN和韧性指标计算。其他故障树结构不能直接套用率加和。
恢复率沿用原包设置；如需重新计算，传入 `--recovery recovery_durations.csv`。

输出目录中：`input_statistics/` 保存由Excel转换的CSV；`parameters/` 保存年度失效率、
底事件拟合、状态汇总和JSON参数；`pinn/` 保存训练损失、状态概率及韧性指标；
`run_manifest.json` 记录来源文件指纹、统计范围、训练设置和执行状态。

运行检查：`python -m unittest discover -s tests -v`。

## 新增流程

已分类故障台账或年度次数 → 用运行暴露量计算年度底事件失效率 → 线性拟合初始率和斜率
→ 独立OR门汇总场站转移率 → JSON接入原PINN → 输出状态概率和韧性指标。

保留原有网络、训练方法、首次到达辅助模型及默认基准参数。
Excel示例用于演示这一流程；`templates/` 中另保留只有列名的CSV接口，便于接入其他统计文件。

## 输入接口

将 `templates/` 中的CSV复制到自行创建的 `private_inputs/` 目录再填。
不要把真实数据填在准备公开的模板里。UTF-8编码，支持BOM。

1. `basic_events.csv`：`basic_event_id,state`。
   底事件用匿名编号，每个事件映射到一个S1–S6；多个底事件可对应同一状态，必须覆盖六个状态。
   分类和屏障条件由你核实，代码不自动解析故障叙述。
2. `annual_exposure.csv`：`basic_event_id,year,exposure_h,time_start_h,time_end_h`。
   年度标签用于匹配；暴露量是同一类事件同一年的实际在险运行小时。
   起止时刻必须是统一模型时间原点之后的小时数，不能填2020、2021等年份来冒充小时。
   观测区间按时间排列、不重叠；可以缺少未观测年份，但不能将未知次数默认为0。
3. 次数来源二选一：
   - `fault_ledger.csv`：`record_id,basic_event_id,year`，一行一个独立故障，编号唯一。
     同一故障的重复维修记录先合并。必须传 `--ledger-complete` 确认台账覆盖所有暴露区间；
     只有这样，有暴露但没记录的年度才算零故障。
   - `annual_counts.csv`：`basic_event_id,year,failure_count`，填写已统计次数。
     必须覆盖每一行暴露量，无故障明确填0。缺行、重复、负数或非整数都会报错。
4. 可选 `recovery_durations.csv`：
   `state,mean_emergency_h,mean_supply_delay_h,mean_repair_h`，S1–S6各一行。
   以三个均值之和的倒数计算恢复率。没传 `--recovery` 时保留原包恢复率并明确注明，
   **不会从故障次数推断维修时间。**

暴露量不能默认等于8760小时，分子分母必须对应同一设备群和风险时间。
多台设备累计的设备小时得到每设备小时率，不能未经论证直接当作场站率。

## 拟合方法与单位

```text
年度失效率 = 年度故障次数 / 对应运行暴露小时数
年度观测时刻 = (起始小时 + 结束小时) / 2
lambda_i(t) = lambda_i0 + alpha_i * t
```

默认各年等权最小二乘，同时约束初始率、斜率非负以对应非递减线性模型。
这是求解有约束最小二乘，不是先拟合再把负数改成零。
会同时导出未约束系数；边界解会警告，不能把受约束上升趋势当作数据本身的结论。

- `--weighting equal`：默认，各年等权。
- `--weighting exposure`：按运行暴露量加权的最小二乘，不是泊松似然法。
- `--constraint nonnegative`：默认，初始率和斜率均非负。
- `--constraint unconstrained`：允许负斜率，但如果观测期或评估期出现负失效率则拒绝。

初始率是模型t=0的拟合截距，不一定是首年实际失效率。零时刻含义用 `--time-origin` 记录。
初始率单位h^-1，斜率h^-2；每年增长量不能不经换算直接当作斜率输入PINN。
年度率放在区间中点，隐含区间内暴露近似均匀。若暴露很不均匀，需提供更细统计或扩展为暴露加权时刻。
每个底事件至少两年，建议三年以上；两点拟合会警告。外推超过观测区间也会警告，不能声称长期趋势已验证。

## 底事件汇总的适用边界

此接口只实现独立OR门相加：一个状态对应底事件的初始率相加，斜率相加。
运行前需传 `--confirm-independent-or`，表示你已核实映射；程序不会自动证明统计独立性。
AND门、共因故障、相关屏障或共享底事件跨多个结果不能直接套用。
此代码不是通用故障树求解器；场站结果的互斥性和事件归属仍需工程核实。

## 怎么运行

在包目录打开终端。只拟合不需要TensorFlow：

```bash
python -m pip install -r requirements-estimation.txt
python estimate_parameters.py --events private_inputs/basic_events.csv --exposure private_inputs/annual_exposure.csv --counts private_inputs/annual_counts.csv --time-origin "请改为实际模型零时刻的定义" --horizon-h 150000 --confirm-independent-or --output estimated_parameters
```

若用逐条台账，将 `--counts private_inputs/annual_counts.csv` 替换为
`--ledger private_inputs/fault_ledger.csv --ledger-complete`。
有恢复均值时追加 `--recovery private_inputs/recovery_durations.csv`。

在原训练环境（Python 3.8、TensorFlow 2.9.0等）接入：

```bash
python -m pip install -r requirements.txt
python pinn_7state_resilience.py --parameters estimated_parameters/model_parameters.json --validate-only
python pinn_7state_resilience.py --parameters estimated_parameters/model_parameters.json
```

`--validate-only`只检查接口，不训练，需NumPy和pandas但不要求TensorFlow。
不加 `--parameters` 仍使用原包基准值，会打印说明，不是重新估计。
无效参数报错，不会静默换回论文参数。PINN时间不能超过参数文件验证的评估范围。

一条命令拟合再训练：

```bash
python run_pipeline.py --events private_inputs/basic_events.csv --exposure private_inputs/annual_exposure.csv --counts private_inputs/annual_counts.csv --time-origin "请改为实际模型零时刻的定义" --horizon-h 150000 --confirm-independent-or --output estimated_parameters_run2 --pinn-output results_run2
```

追加 `--fit-only` 可只拟合。参数输出目录必须为空或未创建，避免覆盖。
如果训练失败，拟合文件保留，直接用 `--parameters` 继续训练。
直接运行PINN仍保留原来的结果覆盖行为，请用新的输出目录；PowerShell可设置
`$env:PINN_OUTPUT_DIR="results_fitted"`。

原默认主PINN与首次到达辅助PINN**各训练80000次**，8000个名义残差点、3001个评价点。
继续支持 `PINN_EPOCHS`、`PINN_ROBUSTNESS_EPOCHS`、`PINN_N_R`、`PINN_N_STAR` 等环境变量。
新代码分别计时两模型训练，不能将主模型一次训练耗时当作整个程序耗时。

## 输出与检查

- `annual_failure_rates.csv`：年度次数、暴露量、观测率、拟合率、残差。
- `basic_event_fits.csv`：底事件截距、斜率、未约束系数、拟合RMSE、R平方及约束标志。
- `state_parameters.csv`：状态汇总参数及来源底事件。
- `model_parameters.json`：模型接口、单位、时间原点、设置、警告及输入指纹。
- 原PINN的五个CSV继续保留，新增 `parameters_used.json` 和 `training_cost.json`。

拟合误差不是PINN概率误差。零故障不等于真实风险为零。未自动生成置信区间。
训练计时为本机新运行的实测值，含首次追踪和日志收集，不替代论文报告的计时结果。

运行测试：`python -m unittest discover -s tests -v`。
所有测试数据都是临时合成数据，不是论文台账。无TensorFlow时训练测试明确跳过。

上传内容包括代码、示例Excel、空CSV模板和说明；真实台账和敏感中间统计留在本地。
`.gitignore` 只提供辅助保护，不保证脱敏。公开这套方法并不自动公开真实输入；
要独立复算真实案例，仍需获准提供匿名年度次数、暴露量、时间原点、映射与实际拟合设置。
