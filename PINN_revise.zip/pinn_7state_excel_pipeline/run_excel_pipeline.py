"""Excel statistics -> estimated lambda_0 / alpha -> both seven-state PINNs."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

from excel_inputs import read_excel_statistics, write_csv_inputs
from estimate_parameters import estimate, make_parser


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--excel', type=Path, default=Path(__file__).with_name('data.xlsx'))
    parser.add_argument('--sheet', help='Optional worksheet name; otherwise detect the template headers.')
    parser.add_argument('--output', type=Path, default=Path('results_excel'))
    parser.add_argument('--fit-only', action='store_true')
    parser.add_argument('--solver', choices=['pinn', 'numerical'], default='pinn')
    parser.add_argument('--smoke-test', action='store_true', help='Train each PINN for 5 iterations with small grids; checks execution, not accuracy.')
    parser.add_argument('--epochs', type=int, help='Main PINN iterations; default 80000 outside smoke mode.')
    parser.add_argument('--robustness-epochs', type=int, help='Auxiliary PINN iterations; defaults to --epochs.')
    parser.add_argument('--residual-points', type=int, help='Nominal residual points; default 8000.')
    parser.add_argument('--evaluation-points', type=int, help='Output times; default 3001.')
    parser.add_argument('--horizon-h', type=float, default=150000)
    parser.add_argument('--weighting', choices=['equal', 'exposure'], default='equal')
    parser.add_argument('--constraint', choices=['nonnegative', 'unconstrained'], default='nonnegative')
    parser.add_argument('--data-kind', choices=['example', 'user_statistics'], default='example')
    parser.add_argument('--recovery', type=Path, help='Optional recovery duration CSV; otherwise original recovery rates are retained.')
    args = parser.parse_args()
    if args.smoke_test and any(v is not None for v in [args.epochs, args.robustness_epochs, args.residual_points, args.evaluation_points]):
        parser.error('--smoke-test cannot be combined with explicit training/grid settings.')
    if args.solver == 'numerical' and (args.smoke_test or any(v is not None for v in [args.epochs, args.robustness_epochs, args.residual_points])):
        parser.error('Numerical mode does not accept PINN training options.')
    if args.output.exists():
        parser.error('Output path already exists. Choose a new --output directory; existing results are preserved.')
    try:
        mapping, observations, source = read_excel_statistics(args.excel, args.sheet)
        if args.horizon_h <= 0 or not __import__('math').isfinite(args.horizon_h):
            raise ValueError('horizon-h must be finite and positive.')
        settings = dict(epochs=5 if args.smoke_test else (args.epochs if args.epochs is not None else 80000),
                        residual_points=60 if args.smoke_test else (args.residual_points if args.residual_points is not None else 8000),
                        evaluation_points=41 if args.smoke_test else (args.evaluation_points if args.evaluation_points is not None else 3001))
        settings['robustness_epochs'] = 5 if args.smoke_test else (args.robustness_epochs if args.robustness_epochs is not None else settings['epochs'])
        if min(settings['epochs'], settings['robustness_epochs']) < 1 or settings['residual_points'] < 6 or settings['evaluation_points'] < 2:
            raise ValueError('Positive iterations, >=6 residual points and >=2 evaluation points are required.')
        converted = args.output / 'input_statistics'
        write_csv_inputs(converted, mapping, observations)
        estimator_args = make_parser().parse_args([
            '--events', str(converted / 'basic_events.csv'), '--exposure', str(converted / 'annual_exposure.csv'),
            '--counts', str(converted / 'annual_counts.csv'), '--time-origin', source['time_origin'],
            '--horizon-h', str(args.horizon_h), '--weighting', args.weighting, '--constraint', args.constraint,
            '--confirm-independent-or', '--output', str(args.output / 'parameters')])
        estimator_args.recovery = args.recovery
        estimator_args.input_metadata = dict(data_kind=args.data_kind, excel_source=source,
            aggregation_note='The Excel workflow uses independent OR rate summation within each S1-S6 group; other fault-tree logic requires a different mapping/aggregation model.')
        parameter_file = estimate(estimator_args)
        manifest = dict(data_kind=args.data_kind, excel_source=source, smoke_test=args.smoke_test, solver=args.solver,
                        training_settings=settings if args.solver == 'pinn' else None, parameter_file='parameters/model_parameters.json',
                        status='parameters_estimated', training_accuracy_assessed=False)
        manifest_path = args.output / 'run_manifest.json'
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
        if args.fit_only:
            return
        if args.solver == 'numerical':
            result = subprocess.run([sys.executable, str(Path(__file__).with_name('solve_numerically.py')),
                                     '--parameters', str(parameter_file.resolve()), '--output', str(args.output / 'numerical'),
                                     '--points', str(settings['evaluation_points'])], check=False)
            manifest.update(status='completed' if result.returncode == 0 else 'numerical_failed', numerical_exit_code=result.returncode)
            manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
            if result.returncode:
                raise SystemExit(result.returncode)
            return
        env = os.environ.copy()
        env.update(PINN_EPOCHS=str(settings['epochs']), PINN_ROBUSTNESS_EPOCHS=str(settings['robustness_epochs']),
                   PINN_N_R=str(settings['residual_points']), PINN_N_STAR=str(settings['evaluation_points']),
                   PINN_T_END=str(args.horizon_h), PINN_OUTPUT_DIR=str((args.output / 'pinn').resolve()))
        print('Starting PINN with Excel-derived parameters.', flush=True)
        if args.smoke_test:
            print('SMOKE TEST: five iterations per model; output values do not establish solution accuracy.', flush=True)
        result = subprocess.run([sys.executable, str(Path(__file__).with_name('pinn_7state_resilience.py')),
                                 '--parameters', str(parameter_file.resolve())], env=env, check=False)
        manifest.update(status='completed' if result.returncode == 0 else 'pinn_failed', pinn_exit_code=result.returncode)
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
        if result.returncode:
            raise SystemExit(result.returncode)
    except (ValueError, OSError, KeyError) as error:
        parser.exit(2, f'Excel pipeline error: {error}\n')


if __name__ == '__main__':
    main()
