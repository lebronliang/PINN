"""Synthetic unit/integration tests. These are NOT manuscript fault statistics."""
import csv
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from estimate_parameters import estimate, make_parser, linear_fit
from model_parameters import load_parameters, baseline_parameters


def write_csv(path, fields, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


class ParameterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.mapping = [{"basic_event_id": f"E{k}", "state": f"S{k}"} for k in range(1, 7)]
        self.exposure, self.counts = [], []
        for k in range(1, 7):
            for year_index in range(3):
                self.exposure.append(dict(basic_event_id=f"E{k}", year=2020 + year_index,
                                          exposure_h=2000, time_start_h=1000 * year_index,
                                          time_end_h=1000 * (year_index + 1)))
                self.counts.append(dict(basic_event_id=f"E{k}", year=2020 + year_index,
                                        failure_count=k * (3 + 2 * year_index)))
        self.save_inputs()

    def save_inputs(self):
        write_csv(self.base / "events.csv", ["basic_event_id", "state"], self.mapping)
        write_csv(self.base / "exposure.csv", ["basic_event_id", "year", "exposure_h", "time_start_h", "time_end_h"], self.exposure)
        write_csv(self.base / "counts.csv", ["basic_event_id", "year", "failure_count"], self.counts)

    def cli_args(self, output="out"):
        return ["--events", str(self.base / "events.csv"), "--exposure", str(self.base / "exposure.csv"),
                "--counts", str(self.base / "counts.csv"), "--time-origin", "Synthetic test origin, not a real station",
                "--horizon-h", "4000", "--confirm-independent-or", "--output", str(self.base / output)]

    def run_estimate(self, output="out"):
        return estimate(make_parser().parse_args(self.cli_args(output)))

    def test_known_linear_fit_and_h_units(self):
        result = load_parameters(self.run_estimate())
        np.testing.assert_allclose(result.intercepts, np.arange(1, 7) * 0.001, rtol=1e-10)
        np.testing.assert_allclose(result.slopes, np.arange(1, 7) * 1e-6, rtol=1e-10)
        with (self.base / "out/annual_failure_rates.csv").open() as f:
            rows = list(csv.DictReader(f))
        self.assertAlmostEqual(float(rows[0]["annual_failure_rate_h_inv"]), 3 / 2000)
        self.assertAlmostEqual(float(rows[0]["time_h"]), 500)
        self.assertEqual(result.provenance["mode"], "estimated_from_user_statistics")

    def test_ledger_counts_equivalence(self):
        first = load_parameters(self.run_estimate())
        ledger = []
        for row in self.counts:
            for i in range(row["failure_count"]):
                ledger.append(dict(record_id=f'{row["basic_event_id"]}-{row["year"]}-{i}',
                                   basic_event_id=row["basic_event_id"], year=row["year"]))
        write_csv(self.base / "ledger.csv", ["record_id", "basic_event_id", "year"], ledger)
        args = make_parser().parse_args(self.cli_args("ledger_out"))
        args.counts, args.ledger, args.ledger_complete = None, self.base / "ledger.csv", True
        second = load_parameters(estimate(args))
        np.testing.assert_allclose(first.intercepts, second.intercepts)
        np.testing.assert_allclose(first.slopes, second.slopes)
        ledger.append(ledger[0])
        write_csv(self.base / "ledger.csv", ["record_id", "basic_event_id", "year"], ledger)
        with self.assertRaisesRegex(ValueError, "Duplicate record_id"):
            estimate(args)

    def test_or_aggregation_and_recovery(self):
        self.mapping.append(dict(basic_event_id="EXTRA", state="S1"))
        self.exposure += [dict(r, basic_event_id="EXTRA") for r in self.exposure if r["basic_event_id"] == "E1"]
        self.counts += [dict(r, basic_event_id="EXTRA") for r in self.counts if r["basic_event_id"] == "E1"]
        self.save_inputs()
        rows = [dict(state=f"S{k}", mean_emergency_h=2, mean_supply_delay_h=3, mean_repair_h=5) for k in range(1, 7)]
        write_csv(self.base / "recovery.csv", list(rows[0]), rows)
        args = make_parser().parse_args(self.cli_args())
        args.recovery = self.base / "recovery.csv"
        params = load_parameters(estimate(args))
        self.assertAlmostEqual(params.intercepts[0], 0.002)
        self.assertAlmostEqual(params.slopes[0], 2e-6)
        np.testing.assert_allclose(params.recovery_rates, 0.1)

    def test_constrained_and_unconstrained_fit(self):
        constrained = linear_fit([1, 2, 3], [3, 2, 1], [10, 10, 10])
        self.assertEqual(constrained["alpha_h_inv2"], 0)
        self.assertAlmostEqual(constrained["lambda0_h_inv"], 2)
        self.assertTrue(constrained["at_constraint_boundary"])
        unconstrained = linear_fit([1, 2, 3], [3, 2, 1], [10, 10, 10], constraint="unconstrained")
        self.assertAlmostEqual(unconstrained["alpha_h_inv2"], -1)
        # Negative intercept OLS -> constrained optimum at b=0, NOT coefficient clipping.
        boundary = linear_fit([1, 2, 3], [0, 1, 2], [1, 1, 1])
        self.assertEqual(boundary["lambda0_h_inv"], 0)
        self.assertAlmostEqual(boundary["alpha_h_inv2"], 8 / 14)

    def test_weighting_and_zero_counts(self):
        fit = linear_fit([1, 2, 3], [3, 2, 1], [1, 2, 3], weighting="exposure")
        self.assertAlmostEqual(fit["lambda0_h_inv"], 10 / 6)
        fit = linear_fit([1, 2, 3], [0, 0, 0], [1, 1, 1])
        self.assertEqual(fit["lambda0_h_inv"], 0)
        self.assertIsNone(fit["r_squared_unweighted"])

    def test_missing_count_is_not_zero(self):
        self.counts.pop()
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, "Counts must cover"):
            self.run_estimate()

    def test_invalid_exposure(self):
        self.exposure[0]["exposure_h"] = 0
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, "positive"):
            self.run_estimate()

    def test_duplicate_year_and_overlap(self):
        self.exposure.append(self.exposure[0])
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.run_estimate()
        self.exposure.pop()
        self.exposure[1]["time_start_h"] = 1
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, "overlap"):
            self.run_estimate()

    def test_one_year_cannot_determine_slope(self):
        self.exposure = [r for r in self.exposure if r["year"] == 2020]
        self.counts = [r for r in self.counts if r["year"] == 2020]
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, "two annual"):
            self.run_estimate()

    def test_unknown_event_and_negative_counts(self):
        self.counts[0]["basic_event_id"] = "unknown"
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, "matching exposure"):
            self.run_estimate()
        self.counts[0]["basic_event_id"] = "E1"
        self.counts[0]["failure_count"] = -1
        self.save_inputs()
        with self.assertRaisesRegex(ValueError, ">= 0"):
            self.run_estimate()

    def test_no_overwrite(self):
        self.run_estimate()
        with self.assertRaisesRegex(ValueError, "not empty"):
            self.run_estimate()

    def test_explicit_confirmation_and_units(self):
        args = make_parser().parse_args(self.cli_args())
        args.confirm_independent_or = False
        with self.assertRaisesRegex(ValueError, "Confirm independent OR"):
            estimate(args)
        file = self.run_estimate()
        raw = json.loads(file.read_text())
        raw["units"]["slope"] = "h^-1/year"
        file.write_text(json.dumps(raw))
        with self.assertRaisesRegex(ValueError, "units"):
            load_parameters(file)

    def test_horizon_rejected(self):
        params = baseline_parameters()
        params.slopes[0] = -1
        with self.assertRaisesRegex(ValueError, "negative"):
            params.validate()
        with self.assertRaisesRegex(ValueError, "exceeds"):
            baseline_parameters().validate(150001)

    def test_empty_templates_fail_without_output(self):
        args = make_parser().parse_args(self.cli_args())
        args.events = ROOT / "templates/basic_events.csv"
        with self.assertRaisesRegex(ValueError, "template is empty"):
            estimate(args)
        self.assertFalse((self.base / "out").exists())

    def test_ledger_confirmation_required(self):
        args = make_parser().parse_args(self.cli_args())
        args.counts = None
        args.ledger = ROOT / "templates/fault_ledger.csv"
        with self.assertRaisesRegex(ValueError, "ledger-complete"):
            estimate(args)
        args.ledger_complete = True
        params = load_parameters(estimate(args))
        np.testing.assert_allclose(params.intercepts, 0)
        np.testing.assert_allclose(params.slopes, 0)
        self.assertTrue(any("zero observed" in w for w in params.provenance["warnings"]))

    def test_bad_schema_is_not_baseline_fallback(self):
        file = self.run_estimate()
        data = json.loads(file.read_text())
        data["state_order"] = ["S6", "S5", "S4", "S3", "S2", "S1"]
        file.write_text(json.dumps(data))
        with self.assertRaisesRegex(ValueError, "state ordering"):
            load_parameters(file)

    @unittest.skipUnless(importlib.util.find_spec("pandas"), "PINN validation needs pandas")
    def test_cli_and_pinn_parameter_loading(self):
        command = [sys.executable, str(ROOT / "run_pipeline.py"), *self.cli_args(), "--fit-only"]
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        parameter_file = self.base / "out/model_parameters.json"
        result = subprocess.run([sys.executable, str(ROOT / "pinn_7state_resilience.py"), "--parameters", str(parameter_file), "--validate-only"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Parameter validation passed", result.stdout)
        import pinn_7state_resilience as pinn
        params = load_parameters(parameter_file)
        np.testing.assert_allclose(pinn.transition_rates_np(np.array([0, 10]), params), params.intercepts + np.array([[0], [10]]) * params.slopes)
        # The recovery indicator must use fitted departure rates too, not baseline constants.
        times = np.array([0., 10.])
        probs = np.zeros((2, 7)); probs[:, 0] = [1, .95]; probs[1, 1] = .05
        indices = pinn.calculate_resilience_indices(times, probs, probs, params)
        hazard = np.sum(params.intercepts) * 10 + np.sum(params.slopes) * 50
        survival = np.exp(-hazard)
        expected = max((.95 - survival) / (1 - survival), 0)
        self.assertAlmostEqual(indices["recovery"].iloc[-1], expected)

    @unittest.skipUnless(importlib.util.find_spec("tensorflow"), "TensorFlow not installed; training smoke test skipped")
    def test_actual_tensorflow_injection_and_training(self):
        import pinn_7state_resilience as pinn
        params = load_parameters(self.run_estimate())
        initial = np.array([[1, 0, 0, 0, 0, 0, 0]], dtype=np.float32)
        points = np.linspace(0, 100, 12, dtype=np.float32).reshape(-1, 1)
        for absorbing in (False, True):
            model = pinn.SevenStatePINN(np.array([[0.]], dtype=np.float32), initial, points,
                                       absorbing_failure=absorbing, parameters=params)
            rhs = model.markov_rhs(pinn.tf.constant(initial), pinn.tf.constant([[0.]]))
            np.testing.assert_allclose(rhs.numpy()[0, 1:], params.intercepts, rtol=1e-6)
            model.train(1, pinn.make_optimizer())
            prediction = model.predict(points)
            np.testing.assert_allclose(prediction.sum(axis=1), 1, atol=2e-7)
            self.assertTrue(np.all(np.isfinite(prediction)))


if __name__ == "__main__":
    unittest.main()
