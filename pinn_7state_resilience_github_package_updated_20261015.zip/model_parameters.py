"""Shared, validated rate parameters; this module does not require TensorFlow."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np

STATES = [f"S{k}" for k in range(1, 7)]
DEFAULT_RECOVERY_RATES = [2.50e-2, 2.20e-2, 1.80e-2, 3.50e-3, 3.00e-3, 2.50e-3]


@dataclass
class ModelParameters:
    intercepts: np.ndarray
    slopes: np.ndarray
    recovery_rates: np.ndarray
    assessment_horizon_h: float
    provenance: dict

    def validate(self, requested_horizon_h=None):
        horizon = self.assessment_horizon_h
        if not np.isfinite(horizon) or horizon <= 0:
            raise ValueError("assessment_horizon_h must be finite and positive.")
        for name in ("intercepts", "slopes", "recovery_rates"):
            a = np.asarray(getattr(self, name), dtype=np.float64)
            if a.shape != (6,) or not np.all(np.isfinite(a)):
                raise ValueError(f"{name} must contain six finite values in S1-S6 order.")
            setattr(self, name, a)
        if np.any(self.intercepts < 0) or np.any(self.recovery_rates < 0):
            raise ValueError("Initial failure rates and recovery rates must be non-negative.")
        # For linear rates, non-negativity at both endpoints guarantees it throughout.
        endpoint = self.intercepts + horizon * self.slopes
        if not np.all(np.isfinite(endpoint)):
            raise ValueError("Failure rates overflow at the assessment horizon.")
        if np.any(endpoint < 0):
            raise ValueError("At least one fitted rate becomes negative within the horizon.")
        if requested_horizon_h is not None:
            if not np.isfinite(requested_horizon_h) or requested_horizon_h <= 0:
                raise ValueError("Requested horizon must be finite and positive.")
            if requested_horizon_h > horizon:
                raise ValueError("Requested PINN horizon exceeds the validated parameter horizon.")
        return self

    def to_dict(self):
        self.validate()
        return {
            "schema_version": 1,
            "state_order": STATES,
            "units": {"time": "h", "intercept": "h^-1", "slope": "h^-2", "recovery": "h^-1"},
            "assessment_horizon_h": self.assessment_horizon_h,
            "lambda_intercepts": self.intercepts.tolist(),
            "lambda_slopes": self.slopes.tolist(),
            "recovery_rates": self.recovery_rates.tolist(),
            "provenance": self.provenance,
        }


def baseline_parameters(horizon_h=150000.0):
    """Original package constants, NOT recomputed from supplied confidential data."""
    return ModelParameters(
        np.array([4.50e-5, 3.50e-5, 2.50e-5, 5.00e-6, 3.00e-6, 1.50e-6]),
        np.array([5.00e-8, 4.00e-8, 3.00e-8, 5.00e-9, 3.00e-9, 1.50e-9]),
        np.array(DEFAULT_RECOVERY_RATES), float(horizon_h),
        {"mode": "published_baseline", "note": "Original aggregated constants; no ledger re-estimation performed."},
    ).validate()


def load_parameters(path, requested_horizon_h=None):
    with Path(path).open(encoding="utf-8-sig") as stream:
        data = json.load(stream)
    if data.get("schema_version") != 1 or data.get("state_order") != STATES:
        raise ValueError("Unsupported schema or state ordering; expected schema 1 and S1-S6.")
    units = {"time": "h", "intercept": "h^-1", "slope": "h^-2", "recovery": "h^-1"}
    if data.get("units") != units:
        raise ValueError("Parameter units do not match the hour-based PINN model.")
    return ModelParameters(
        np.asarray(data["lambda_intercepts"], dtype=float),
        np.asarray(data["lambda_slopes"], dtype=float),
        np.asarray(data["recovery_rates"], dtype=float),
        float(data["assessment_horizon_h"]), data.get("provenance", {}),
    ).validate(requested_horizon_h)
