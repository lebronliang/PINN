"""Ledger/counts -> annual basic-event rates -> linear fits -> S1-S6 parameters.

No real fault records or invented paper results are included. See README.md.
Only explicitly confirmed independent OR rate aggregation is supported.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

from model_parameters import ModelParameters, STATES, DEFAULT_RECOVERY_RATES


def read_csv(path, required):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or len(set(reader.fieldnames)) != len(reader.fieldnames):
            raise ValueError(f"{path}: missing or duplicate CSV headers.")
        missing = set(required) - set(reader.fieldnames)
        if missing:
            raise ValueError(f"{path}: missing columns {sorted(missing)}.")
        rows = []
        for line, row in enumerate(reader, 2):
            if None in row or any(row.get(key) is None for key in required):
                raise ValueError(f"{path}:{line}: malformed CSV row.")
            row = {k: (v or "").strip() for k, v in row.items()}
            if not any(row.values()):
                continue
            if any(not row[key] for key in required):
                raise ValueError(f"{path}:{line}: required values must not be blank.")
            rows.append(row)
    if not rows:
        raise ValueError(f"{path}: template is empty; supply your approved data first.")
    return rows


def number(value, label, minimum=0.0):
    try:
        value = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} must be numeric.") from None
    if not np.isfinite(value) or value < minimum:
        raise ValueError(f"{label} must be finite and >= {minimum}.")
    return value


def integer(value, label, minimum=0):
    value = number(value, label, minimum)
    if not value.is_integer():
        raise ValueError(f"{label} must be an integer.")
    return int(value)


def linear_fit(time_h, rates, exposures, weighting="equal", constraint="nonnegative"):
    """Fit lambda(t)=b+a*t in hour units; no clipping of fitted predictions.

    'nonnegative' is exact two-parameter constrained least squares (b>=0,a>=0).
    The boundary candidates are compared to the feasible unconstrained solution.
    'unconstrained' is OLS/WLS; later physical validation may reject its output.
    """
    x, y, exposure = [np.asarray(v, dtype=float) for v in (time_h, rates, exposures)]
    if x.ndim != 1 or x.shape != y.shape or x.shape != exposure.shape or len(x) < 2:
        raise ValueError("At least two annual observations are required for every basic event.")
    if not all(np.all(np.isfinite(v)) for v in (x, y, exposure)):
        raise ValueError("Non-finite regression input.")
    if len(np.unique(x)) < 2 or np.any(x < 0) or np.any(y < 0) or np.any(exposure <= 0):
        raise ValueError("Regression needs distinct non-negative times, non-negative rates and positive exposures.")
    if weighting not in ("equal", "exposure") or constraint not in ("nonnegative", "unconstrained"):
        raise ValueError("Unsupported weighting or constraint.")
    w = np.ones_like(x) if weighting == "equal" else exposure / np.mean(exposure)
    scale = max(float(np.max(x)), 1.0)
    xs = x / scale
    design = np.column_stack([np.ones_like(xs), xs])
    unconstrained = np.linalg.lstsq(design * np.sqrt(w[:, None]), y * np.sqrt(w), rcond=None)[0]
    if constraint == "unconstrained":
        chosen = unconstrained
    else:
        candidates = [np.array([max(float(np.average(y, weights=w)), 0.0), 0.0]),
                      np.array([0.0, max(float(np.sum(w * xs * y) / np.sum(w * xs * xs)), 0.0)]),
                      np.zeros(2)]
        if np.all(unconstrained >= 0):
            candidates.append(unconstrained)
        chosen = min(candidates, key=lambda c: float(np.sum(w * (y - design @ c) ** 2)))
    b, a = float(chosen[0]), float(chosen[1] / scale)
    prediction = b + a * x
    sse = float(np.sum((y - prediction) ** 2))
    sst = float(np.sum((y - np.mean(y)) ** 2))
    return {
        "lambda0_h_inv": b, "alpha_h_inv2": a,
        "unconstrained_lambda0_h_inv": float(unconstrained[0]),
        "unconstrained_alpha_h_inv2": float(unconstrained[1] / scale),
        "rate_rmse_h_inv": float(np.sqrt(sse / len(y))),
        "r_squared_unweighted": None if sst == 0 else 1.0 - sse / sst,
        "weighted_sse": float(np.sum(w * (y - prediction) ** 2)),
        "at_constraint_boundary": bool(constraint == "nonnegative" and (b == 0 or a == 0)),
    }


def estimate(args):
    if not args.confirm_independent_or:
        raise ValueError("Confirm independent OR aggregation with --confirm-independent-or after reviewing the mapping.")
    horizon = number(args.horizon_h, "horizon_h")
    if horizon == 0:
        raise ValueError("horizon_h must be positive.")
    mapping = {}
    for row in read_csv(args.events, ["basic_event_id", "state"]):
        event, state = row["basic_event_id"], row["state"]
        if event in mapping or state not in STATES:
            raise ValueError("Every basic_event_id must be unique and mapped to one of S1-S6.")
        mapping[event] = state
    if set(mapping.values()) != set(STATES):
        raise ValueError("The mapping must cover all six abnormal states S1-S6.")

    observations = {}
    for row in read_csv(args.exposure, ["basic_event_id", "year", "exposure_h", "time_start_h", "time_end_h"]):
        event = row["basic_event_id"]
        year = integer(row["year"], "year", 1)
        key = (event, year)
        if event not in mapping or key in observations:
            raise ValueError("Unknown basic event or duplicate event-year in exposure data.")
        start = number(row["time_start_h"], "time_start_h")
        end = number(row["time_end_h"], "time_end_h")
        exposure = number(row["exposure_h"], "exposure_h")
        if end <= start or exposure <= 0:
            raise ValueError("Every observed interval must have positive width and operating exposure.")
        observations[key] = dict(basic_event_id=event, state=mapping[event], year=year,
                                 time_start_h=start, time_end_h=end, time_h=(start + end) / 2,
                                 exposure_h=exposure, failure_count=0)
    if {k[0] for k in observations} != set(mapping):
        raise ValueError("Every mapped basic event needs annual exposure data.")

    if args.ledger:
        if not args.ledger_complete:
            raise ValueError("Ledger mode needs --ledger-complete: absent events count as zero only for fully covered exposure rows.")
        # An empty ledger with a valid header legitimately denotes zero faults.
        try:
            ledger = read_csv(args.ledger, ["record_id", "basic_event_id", "year"])
        except ValueError as error:
            if "template is empty" not in str(error):
                raise
            ledger = []
        seen = set()
        for row in ledger:
            if row["record_id"] in seen:
                raise ValueError("Duplicate record_id: deduplicate ledger records before counting.")
            seen.add(row["record_id"])
            key = (row["basic_event_id"], integer(row["year"], "year", 1))
            if key not in observations:
                raise ValueError("Every ledger event must have a matching exposure row and mapping.")
            observations[key]["failure_count"] += 1
    else:
        seen = set()
        for row in read_csv(args.counts, ["basic_event_id", "year", "failure_count"]):
            key = (row["basic_event_id"], integer(row["year"], "year", 1))
            if key in seen or key not in observations:
                raise ValueError("Duplicate counts or counts without matching exposure data.")
            seen.add(key)
            observations[key]["failure_count"] = integer(row["failure_count"], "failure_count")
        if seen != set(observations):
            raise ValueError("Counts must cover every exposure row; enter zero explicitly for zero-failure years.")

    fits, annual, warnings = [], [], []
    for event in sorted(mapping):
        rows = sorted((v for k, v in observations.items() if k[0] == event), key=lambda v: v["year"])
        for prev, current in zip(rows, rows[1:]):
            if current["time_start_h"] < prev["time_end_h"]:
                raise ValueError(f"{event}: intervals overlap or the time origin changes between years.")
        for row in rows:
            row["annual_failure_rate_h_inv"] = row["failure_count"] / row["exposure_h"]
        fit = linear_fit([r["time_h"] for r in rows], [r["annual_failure_rate_h_inv"] for r in rows],
                         [r["exposure_h"] for r in rows], args.weighting, args.constraint)
        b, a = fit["lambda0_h_inv"], fit["alpha_h_inv2"]
        if b < 0 or b + a * max(horizon, rows[-1]["time_end_h"]) < 0:
            raise ValueError(f"{event}: unconstrained fit produces negative physical rates; no clipping applied.")
        if len(rows) == 2:
            warnings.append(f"{event}: only two annual observations; no residual degrees of freedom for trend validation.")
        if sum(r["failure_count"] for r in rows) == 0:
            warnings.append(f"{event}: zero observed failures; zero fitted rate is not evidence of zero true risk.")
        if fit["at_constraint_boundary"]:
            warnings.append(f"{event}: constrained optimum is on a boundary; inspect the unconstrained coefficients.")
        if horizon > rows[-1]["time_end_h"]:
            warnings.append(f"{event}: assessment extends beyond observed exposure intervals; extrapolation is not validated.")
        fits.append(dict(basic_event_id=event, state=mapping[event], n_years=len(rows),
                         total_failures=sum(r["failure_count"] for r in rows),
                         weighting=args.weighting, constraint=args.constraint, **fit))
        for row in rows:
            row["fitted_rate_h_inv"] = b + a * row["time_h"]
            row["residual_h_inv"] = row["annual_failure_rate_h_inv"] - row["fitted_rate_h_inv"]
            annual.append(row)

    recovery = list(DEFAULT_RECOVERY_RATES)
    recovery_source = "Original package baseline recovery rates; NOT estimated from failure counts."
    if args.recovery:
        lookup = {}
        for row in read_csv(args.recovery, ["state", "mean_emergency_h", "mean_supply_delay_h", "mean_repair_h"]):
            state = row["state"]
            if state not in STATES or state in lookup:
                raise ValueError("Recovery input must have one row per state S1-S6.")
            total = sum(number(row[k], k) for k in ["mean_emergency_h", "mean_supply_delay_h", "mean_repair_h"])
            if total <= 0:
                raise ValueError("Mean total recovery duration must be positive.")
            lookup[state] = 1.0 / total
        if set(lookup) != set(STATES):
            raise ValueError("Recovery input must cover every state S1-S6.")
        recovery = [lookup[s] for s in STATES]
        recovery_source = "Reciprocal of supplied mean emergency + supply-delay + repair duration."

    sources = {name: {"filename": Path(path).name, "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest()}
               for name, path in [("events", args.events), ("exposure", args.exposure),
                                  ("ledger", args.ledger), ("counts", args.counts), ("recovery", args.recovery)] if path}
    provenance = {
        "mode": "estimated_from_user_statistics", "time_origin": args.time_origin,
        "observation_time": "Midpoint of supplied hour intervals; assumes exposure is uniform within each interval.",
        "annual_rate": "failure_count / exposure_h", "weighting": args.weighting, "constraint": args.constraint,
        "aggregation": "Independent OR rate summation within each state; not a general fault-tree solver.",
        "recovery_source": recovery_source, "input_files": sources, "warnings": warnings,
        "notice": "New calculation interface; no claim that fitting these inputs reproduces published parameters.",
    }
    state_rows = []
    for state in STATES:
        items = [f for f in fits if f["state"] == state]
        state_rows.append(dict(state=state, basic_events=";".join(f["basic_event_id"] for f in items),
                               lambda0_h_inv=sum(f["lambda0_h_inv"] for f in items),
                               alpha_h_inv2=sum(f["alpha_h_inv2"] for f in items),
                               recovery_rate_h_inv=recovery[STATES.index(state)]))
    parameters = ModelParameters(np.array([r["lambda0_h_inv"] for r in state_rows]),
                                 np.array([r["alpha_h_inv2"] for r in state_rows]),
                                 np.array(recovery), horizon, provenance).validate()
    # Only write after all data and physical checks have passed; never overwrite previous runs.
    out = Path(args.output)
    if out.exists() and any(out.iterdir()):
        raise ValueError("Output directory is not empty. Choose a new directory to preserve earlier results.")
    out.mkdir(parents=True, exist_ok=True)
    for name, rows in [("annual_failure_rates.csv", annual), ("basic_event_fits.csv", fits), ("state_parameters.csv", state_rows)]:
        with (out / name).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    with (out / "model_parameters.json").open("w", encoding="utf-8") as stream:
        json.dump(parameters.to_dict(), stream, indent=2, ensure_ascii=False, allow_nan=False)
    print(f"Parameter file: {(out / 'model_parameters.json').resolve()}")
    for warning in warnings:
        print("WARNING:", warning)
    return out / "model_parameters.json"


def make_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--events", required=True, help="Basic-event ID to S1-S6 mapping CSV.")
    parser.add_argument("--exposure", required=True, help="Annual operating exposure and hour-based time intervals CSV.")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--ledger", help="One classified fault occurrence per record_id.")
    source.add_argument("--counts", help="Annual counts including explicit zeros.")
    parser.add_argument("--ledger-complete", action="store_true", help="Confirm complete fault coverage of every exposure row.")
    parser.add_argument("--time-origin", required=True, help="Meaning of t=0, shared by every input interval and PINN.")
    parser.add_argument("--horizon-h", type=float, default=150000.0)
    parser.add_argument("--weighting", choices=["equal", "exposure"], default="equal")
    parser.add_argument("--constraint", choices=["nonnegative", "unconstrained"], default="nonnegative")
    parser.add_argument("--confirm-independent-or", action="store_true")
    parser.add_argument("--recovery", help="Optional six-state mean recovery duration CSV; otherwise retains original recovery rates.")
    parser.add_argument("--output", default="estimated_parameters")
    return parser


def main():
    parser = make_parser()
    args = parser.parse_args()
    try:
        estimate(args)
    except (ValueError, OSError, KeyError) as error:
        parser.exit(2, f"Input/estimation error: {error}\n")


if __name__ == "__main__":
    main()
