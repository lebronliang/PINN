# Update 2026-10-15

## Added

- Blank interfaces for classified fault ledgers, annual counts/exposure,
  basic-event state mapping and optional recovery-duration means.
- Annual basic-event rates and explicit hour-based linear regression, with
  documented equal/exposure weighting and constrained/unconstrained options.
- Independent OR aggregation and inspectable CSV/JSON intermediates with input
  fingerprints, fit diagnostics and extrapolation warnings.
- A one-command estimation/training driver, parameter validation mode and tests.
- Chinese and English documentation, including confidentiality guidance.

## Solver changes

- Both PINNs now accept the same loaded parameter object. The NumPy rate function
  used by the recovery index also accepts it; there is no hidden use of default
  departure rates in the fitted-parameter path.
- Original baseline values remain available when no parameter file is supplied.
- Added exact parameter provenance and measured main/auxiliary training timings.
- Network architecture, gradient projection, loss formulation, point generation
  and resilience definitions are otherwise retained from the input package.

## Validation scope

Parameter estimation and CLI-to-PINN parameter loading were checked using
synthetic tests, with syntax compilation of all Python modules. Tests contain no
real station data. TensorFlow is not installed on the development machine, so
the one-step training integration test is included but skipped there. Full PINN
training and reproduction of the manuscript results have not been performed.

This addition is an executable data-processing interface, not a claim about the
historical fitting procedure or disclosure of the confidential input statistics.
