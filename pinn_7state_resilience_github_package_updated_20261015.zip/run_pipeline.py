"""Estimate rate parameters and optionally launch the existing PINN solver."""
import os
from pathlib import Path
import subprocess
import sys

from estimate_parameters import make_parser, estimate


def main():
    parser = make_parser()
    parser.description = __doc__
    parser.add_argument("--fit-only", action="store_true", help="Export parameters without starting PINN training.")
    parser.add_argument("--pinn-output", default="results_from_fitted_parameters")
    args = parser.parse_args()
    try:
        parameter_path = estimate(args)
    except (ValueError, OSError, KeyError) as error:
        parser.exit(2, f"Input/estimation error: {error}\n")
    if args.fit_only:
        return
    output = Path(args.pinn_output)
    if output.exists() and any(output.iterdir()):
        parser.exit(2, "PINN output directory is not empty. Parameter estimates are preserved; choose a new --pinn-output.\n")
    env = dict(os.environ, PINN_OUTPUT_DIR=str(output.resolve()))
    command = [sys.executable, str(Path(__file__).with_name("pinn_7state_resilience.py")),
               "--parameters", str(parameter_path.resolve())]
    print("Launching PINN with fitted parameters.", flush=True)
    result = subprocess.run(command, env=env, check=False)
    if result.returncode:
        print("PINN did not finish. Parameter estimates remain available for a later training run.", file=sys.stderr)
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
