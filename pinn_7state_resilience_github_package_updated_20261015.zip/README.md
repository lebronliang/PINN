# Seven-state HRS resilience: parameter estimation and PINN

This package connects classified fault records (or annual counts) to annual
basic-event failure rates, fitted linear parameters, station-level transition
rates and the existing gradient-calibrated PINN. The original published baseline
remains a separate mode. **No confidential fault records are included. The new
estimation interface has not been run on the original station records and does
not establish which fitting procedure was used historically.** It does not claim
to regenerate the published parameters without their underlying input data.

Chinese instructions: [README_zh.md](README_zh.md).

## Files and workflow

```text
classified fault ledger OR annual counts
  + annual operating exposure and hour-based observation intervals
  + basic-event-to-state mapping
                |
       estimate_parameters.py
                |
annual_failure_rates.csv -> basic_event_fits.csv -> state_parameters.csv
                |
      model_parameters.json
                |
      pinn_7state_resilience.py
                |
state probabilities and resilience indices
```

- `estimate_parameters.py`: counting, annual rates, fitting, diagnostics, independent OR aggregation.
- `model_parameters.py`: shared parameter schema, baseline and physical checks.
- `pinn_7state_resilience.py`: original solver, now accepting fitted JSON parameters.
- `run_pipeline.py`: estimation followed by PINN training in one command.
- `templates/`: header-only CSV interfaces, with no invented or confidential data.
- `tests/test_pipeline.py`: synthetic temporary test inputs only, not paper statistics.

The main PINN, auxiliary absorbing-state first-passage PINN and recovery-index
calculation all use the same loaded parameters. Fitting failure rates does not
estimate recovery durations automatically.

## Environment

Parameter estimation does not require TensorFlow:

```bash
python -m pip install -r requirements-estimation.txt
```

For training, use a separate environment compatible with the original package
(Python 3.8, TensorFlow 2.9.0, Ubuntu 20.04, CUDA 11.2, NVIDIA A100):

```bash
python -m pip install -r requirements.txt
```

The original pinned training requirements are retained. Modern Python versions
may not install TensorFlow 2.9.0. CPU training is possible but may be much slower.
An estimation-only environment is not automatically a training environment.

## Input interfaces

Copy empty templates to a local `private_inputs/` folder and populate them there.
Keep the public templates empty. CSV files use UTF-8 (BOM accepted). Use anonymous
IDs; do not include names, contacts or confidential free-text maintenance notes.

### basic_events.csv

`basic_event_id,state`

Every basic-event ID is unique and assigned to one destination S1-S6. Multiple
events may map to one state, and all six states must be covered. Classification
and safety-barrier conditions require engineering review; the program does not
infer them from narrative records.

### annual_exposure.csv

`basic_event_id,year,exposure_h,time_start_h,time_end_h`

- `year`: calendar-year label for matching and sorting, NOT the regression coordinate.
- `exposure_h`: actual at-risk operating hours for that event category and year.
- `time_start_h`, `time_end_h`: observation interval on a shared model time axis,
  measured in hours from the same t=0 for every event and subsequent PINN run.

One row per observed event-year, including zero-failure years. At least two years
with distinct midpoints are required; three or more are preferable. Intervals
must be chronological and non-overlapping. Gaps are allowed as unobserved periods,
not silently treated as zero-failure years. Counts and exposure must describe the
same population. Pooled component-hours give a per-component rate, not automatically
a station-level rate: event definitions and aggregation must be justified.

Annual rates are assigned to interval midpoints, assuming operating exposure is
approximately uniform within each interval. For strongly uneven exposure, prepare
finer statistics or adapt the estimator to use exposure-weighted observation times.
Do not use calendar years as hours, assume 8,760 operating hours in every year,
or insert an annual rate increment directly as an h^-2 slope.

### Choose one count source

**fault_ledger.csv:** `record_id,basic_event_id,year`

One distinct, classified fault occurrence per globally unique `record_id`.
Consolidate repeated maintenance visits for the same occurrence before counting.
Every event requires a matching exposure row. `--ledger-complete` explicitly
confirms complete coverage of all supplied intervals; absent occurrences are only
then counted as zero. A header-only ledger is allowed with this confirmation and
populated mapping/exposure inputs. Do not duplicate one fault across independent
event categories without an appropriate engineering model.

**annual_counts.csv:** `basic_event_id,year,failure_count`

Supply non-negative integer counts for every exposure row, including explicit
zeros. Missing rows, duplicate keys, unknown IDs and invalid exposures cause errors.

### Optional recovery_durations.csv

`state,mean_emergency_h,mean_supply_delay_h,mean_repair_h`

One row per S1-S6. Recovery rate = reciprocal of the sum of these mean durations,
in h^-1. The means must be non-negative and their sum positive. Without `--recovery`,
the original package's recovery rates are retained and labeled as such in metadata.
They are NOT inferred from failure counts.

## Estimation method

```text
annual_rate[i,y] = failure_count[i,y] / exposure_h[i,y]        [h^-1]
t[i,y] = (time_start_h[i,y] + time_end_h[i,y]) / 2             [h]
lambda_i(t) = lambda_i0 + alpha_i * t
minimize sum_y w[i,y] * (annual_rate[i,y] - lambda_i0 - alpha_i*t[i,y])^2
```

Default `--weighting equal` gives each year equal weight. Optional
`--weighting exposure` gives exposure-weighted least squares; it is not a Poisson
likelihood fit. Settings are recorded in the output.

Default `--constraint nonnegative` imposes lambda_i0 >= 0 and alpha_i >= 0 to
implement the assumed non-decreasing linear-rate model. The code solves the
two-parameter constrained least-squares problem, NOT post-fit coefficient clipping.
Unconstrained and selected coefficients are both exported. Boundary solutions
generate warnings; forcing a non-decreasing trend is not evidence of degradation.
`--constraint unconstrained` allows negative slopes, but rates must remain
non-negative over the observations and requested horizon. Invalid fits stop the
pipeline; they never silently fall back to published rates.

The intercept is the fitted rate at the shared model t=0, not necessarily the
first observed annual rate. `--time-origin` records its physical meaning. Slopes
are in h^-2. Shifting the time origin changes the intercept.

### Fault-tree reduction supported here

Only independent OR rate aggregation is implemented:

```text
lambda_k0 = sum of lambda_i0 for basic events assigned to Sk
alpha_k   = sum of alpha_i   for basic events assigned to Sk
```

`--confirm-independent-or` is mandatory: it records user confirmation, not a
statistical independence test. This is **not a general fault-tree solver**.
AND gates, common-cause faults, dependent barriers and shared events across multiple
outcomes need explicit modeling beyond this interface. Mutually exclusive station
outcomes must also be consistently defined; IDs alone cannot establish validity.
Such extensions may require nonlinear rates and changes to the solver interface.

Fit diagnostics include annual residuals, RMSE, unweighted R-squared (blank for
constant observations), unconstrained coefficients and warnings for boundary fits,
two-point fits, zero counts and extrapolation. No confidence intervals are claimed.
Zero observed faults do not establish zero true risk. Extrapolation to 150,000 h
is a modeling assumption, not a validated long-term trend. These fit errors are
NOT PINN state-probability prediction errors.

## Run

Run commands from this package directory after filling the private input files.
Replace the example time-origin text with the actual origin used in your model.

### Estimate from annual statistics

```bash
python estimate_parameters.py --events private_inputs/basic_events.csv --exposure private_inputs/annual_exposure.csv --counts private_inputs/annual_counts.csv --time-origin "Your actual model time origin" --horizon-h 150000 --confirm-independent-or --output estimated_parameters
```

For ledger mode, replace `--counts private_inputs/annual_counts.csv` with
`--ledger private_inputs/fault_ledger.csv --ledger-complete`.
Add `--recovery private_inputs/recovery_durations.csv` if recovery data are available.
Choose a new output folder for each run: existing estimates are never overwritten.

### Validate and train with fitted parameters

```bash
python pinn_7state_resilience.py --parameters estimated_parameters/model_parameters.json --validate-only
python pinn_7state_resilience.py --parameters estimated_parameters/model_parameters.json
```

Validation needs NumPy and pandas, but not TensorFlow. Training needs TensorFlow.
An invalid JSON file never falls back to the baseline. The JSON horizon is used
unless `PINN_T_END` is set; a longer horizon is rejected until the parameter file
is regenerated and validated for it.

### Estimate and train in one command

```bash
python run_pipeline.py --events private_inputs/basic_events.csv --exposure private_inputs/annual_exposure.csv --counts private_inputs/annual_counts.csv --time-origin "Your actual model time origin" --horizon-h 150000 --confirm-independent-or --output estimated_parameters_run2 --pinn-output results_run2
```

Add `--fit-only` to export without training. If training fails, estimates remain
available: resume with `pinn_7state_resilience.py --parameters ...` instead of
rerunning estimation into a non-empty directory.

### Original baseline

```bash
python pinn_7state_resilience.py
```

Without `--parameters`, the script announces that it uses the original baseline
constants, NOT new ledger estimates. Defaults remain 80,000 iterations for the
main PINN AND 80,000 for the first-passage PINN, 8,000 nominal residual points,
3,001 evaluation points and 150,000 h. Environment overrides remain available:
`PINN_EPOCHS`, `PINN_ROBUSTNESS_EPOCHS`, `PINN_N_R`, `PINN_N_STAR`, `PINN_T_END`,
`PINN_GATE_TIME`, `PINN_OUTPUT_DIR`, and the learning-rate variables in the script.
PowerShell example: `$env:PINN_OUTPUT_DIR="results_fitted"`.
Direct PINN runs retain the original overwrite behavior; use a new output folder.
The one-command pipeline rejects non-empty output folders.

## Outputs

Estimation:

- `annual_failure_rates.csv`: counts, exposures, intervals, observed/fitted rates, residuals.
- `basic_event_fits.csv`: fitted and unconstrained coefficients and diagnostics.
- `state_parameters.csv`: aggregated S1-S6 parameters and contributing event IDs.
- `model_parameters.json`: units, state order, horizon, origin, method, recovery
  source, warnings and SHA-256 input fingerprints (no raw ledger record IDs).

PINN outputs:

- `state_probabilities.csv`
- `resilience_indices.csv`
- `resilience_summary.csv`
- `main_pinn_training_loss.csv`
- `robustness_pinn_training_loss.csv`
- `parameters_used.json`: exact input parameters for that run.
- `training_cost.json`: main and auxiliary training times, separately and combined.
  These are new machine-specific measurements, not the paper's recorded timings.
  Timing includes first-step tracing and loss logging, excluding model construction
  and inference; this is not a complete deployment-time measurement.

## Tests and confidentiality

```bash
python -m unittest discover -s tests -v
```

Tests use temporary synthetic fixtures to verify known fits, units, aggregation,
recovery, input errors and CLI parameter loading. A one-step TensorFlow test is
explicitly skipped when TensorFlow is unavailable. Tests do not validate real
station parameters or reproduce paper results.

Keep raw records local. Review derived CSV/JSON statistics and metadata filenames
before publication: they may also be confidential. `.gitignore` excludes suggested
private-input and result folders but does not replace manual review. The package
provides a reproducible **procedure**, not undisclosed real inputs. Independent
recalculation of real station parameters still needs authorized anonymized counts,
exposures, origin, mapping and actual estimation settings. None are fabricated here.
